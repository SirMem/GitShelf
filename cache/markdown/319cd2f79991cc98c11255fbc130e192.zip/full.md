# 2021考研高等数学0基础课

高等数学精讲

主讲：武忠祥教授

![](images/0b55064b3e1d461d4b4be20eeb9c3fca5b6093f3c461830e06804cb537b884aa.jpg)

# 老师简介

![](images/7a2ccd9b17e63b9bffa3751eebb56f37377eb9790524dbce1ead934140244a9e.jpg)

# 主讲人

# 武忠祥老师

n 李永乐考研团队

核心成员

n 原西安交通大学数学系教授  
n 美国爱荷华大学访问学者  
面向二十一世纪国家级重点教材《工科数学分析基础》主编  
曾获国家优秀教材等奖《考研数学复习全书》

《高等数学辅导讲义》等畅销书主编  
n 拥有十余年考研辅导经验

# 老师简介

![](images/71a2c941f2f381aec6e38c01adbe0c942c7e178959190d2e6478d2d0145ef7e2.jpg)

![](images/c3b9bb2e8a06cbeb71b682cc9a6f187be39eae6732ef78309ff26217396e7df2.jpg)

@武忠祥考研

![](images/cb3ebd25e697f5f0d102a9400cbf1a0dcc9e40c460eb533367aefed8dfd80732.jpg)

公众号：武忠祥考研

![](images/dd715e40766ecaf003b5c527340987270a5b6445b384e081ca887529ce9e66bb.jpg)

![](images/ba62f0e2ae02f4e0964d3aaa37a55e47f8371e68d13c2652276223159e388ee5.jpg)

# 第一章 函数与极限

# 第一节 映射与函数

映射   
二、 函数

# 映射

# 函数

# 1. 函数概念

定义 如果对于每个数 $\boldsymbol { x } \in D$ ,变量 $y$ 按照一定的法则总有一个确定的 $y$ 和它对应, 则称 $x$ y是 的函数, 记为$y = f ( x )$ .常称 $x$ 为自变量， $y$ 为因变量, $D$ 为定义域.

定义域 $D _ { f } = D .$

值域

【注】函数概念有两个基本要素：定义域、对应法则.

【例1】 函数

$$
y = | x | = \left\{ \begin{array}{l l} - x, & x <   0, \\ x, & x \geq 0 \end{array} \right.
$$

称为绝对值函数.

![](images/f253c538829ab4494dba206ea399b3d07e583a06cd0e1fe26224aacd628cc4b3.jpg)

【例2】 函数

$$
y = \operatorname {s g n} x = \left\{ \begin{array}{l l} - 1, & x <   0, \\ 0, & x = 0, \\ 1, & x > 0 \end{array} \right.
$$

![](images/05b1216af2a8a74ce66303dad874890ff9595d54cd94f63b688a4f4027207da5.jpg)

称为符号函数.

【例3】设 $x$ 为任意实数，不超过 $x$ 的最大整数称为 $x$

的整数部分，记为 $[ x ]$ .函数 $y = [ x ]$ 称为取整函数.

# 2. 函数的几种特性

# 函数的有界性

设 $X \subset D$

有上界： $\forall x \in X , f ( x ) \leq M _ { 1 }$

有下界： 2x  X , f (x)  M

有界： $\forall x \in X , | f ( x ) | \leq M$ 有界 $\Leftrightarrow$ 有上界且有下界

无界： $\forall M > \mathbf { 0 } , \exists x _ { 0 } \in X .$ , 使 $\left| f ( x _ { 0 } ) > M \right.$

# 函数的单调性

设区间 $I \subset D$

单调增： $\forall x _ { 1 } , x _ { 2 } \in I ;$ 当 $x _ { 1 } < x _ { 2 }$ 时,恒有 $f ( x _ { 1 } ) < f ( x _ { 2 } )$

单调减： , ,1 2x x  I 当 $x _ { 1 } < x _ { 2 }$ 时,恒有 $f ( x _ { 1 } ) > f ( x _ { 2 } )$

# （3） 函数的奇偶性

设 $D$ 关于原点对称

偶函数： $f ( - x ) = f ( x ) \quad x \in D$

奇函数： $f ( - x ) = - f ( x ) \quad x \in D$

【注】偶函数的图形关于 $y$ 轴对称 ， 奇函数的图形关于原点对称,

且若 $f ( x )$ 在 $x = 0$ 处有定义,则 $f ( { \bf 0 } ) = { \bf 0 } .$

# （4） 函数的周期性

定义 若存在实数 $T > 0$ ,对于任意 $x$ ,恒有 $f ( x + T ) = f ( x )$

则称 $y = f ( x )$ 为周期函数.使得上式成立的最小正数 $T$

称为最小正周期，简称为函数 $f ( x )$ 的周期.

【例4】 狄利克雷函数

$$
D (x) = \left\{ \begin{array}{l l} 1, & x \in Q, \\ 0, & x \in Q ^ {c}. \end{array} \right.
$$

# 3.反函数与复合函数

# 反函数

定义设函数 $y = f ( x )$ 的定义域为 $\pmb { D }$ ，值域为 $R _ { \mathrm { , } }$ .若对任意$\boldsymbol { y } \in R _ { y }$ ，有唯一确定的 $\boldsymbol { x } \in D$ ，使得 $y = f ( x )$ ，则记为 $x = f ^ { - 1 } ( y )$ 称其为函数 $y = f ( x )$ 的反函数.

【注】函数 $y = f ( x )$ 与其反函数$\boldsymbol { y } = \boldsymbol { f } ^ { - 1 } ( \boldsymbol { x } )$ 的图形关于直线$y = x$ 对称。

![](images/185cb8001b546531dbbc327941d4f827228d13c20c73ae035eb0542d915ff5d4.jpg)

# 复合函数

定义 设 $y = f ( u )$ 的定义域为 $D _ { f } , \pmb { u } = \pmb { g } ( \pmb { x } )$ 的 定 义 域 为 $D _ { g }$

值域为 $R _ { g }$ , 若 $D _ { f } \cap R _ { g } \neq \phi ,$ 则称函数 $y = f [ g ( x ) ]$ 为函数

$y = f ( u )$ 与 $\pmb { u } = \pmb { g } ( \pmb { x } )$ 的复合函数.它的定义域为

$$
\left\{x \mid x \in D _ {g}, g (x) \in D _ {f} \right\}
$$

【例5】设 $g ( x ) = \{ \begin{array} { l l } { 2 - x , } & { x \leq 0 } \\ { x + 2 , } & { x > 0 } \end{array} , f ( x ) = \{ \begin{array} { l l } { x ^ { 2 } , } & { x < 0 } \\ { - x , } & { x \geq 0 } \end{array} $    , ( )2, 0 f xx x   , 0      2 x x      , 求 g[ f ( x )] $g [ f ( x ) ]$

及 $f [ g ( x ) ]$

# 4. 函数的运算

$$
\begin{array}{l} f \pm g: \quad (f \pm g) (x) = f (x) \pm g (x) \\ f \cdot g: \quad (f \cdot g) (x) = f (x) \cdot g (x) \\ \frac {f}{g}: \qquad (\frac {f}{g}) (x) = \frac {f (x)}{g (x)} \\ \end{array}
$$

【例6】设函数 $f ( x )$ 的定义域为 $( - l , l )$ , 证明必存在 $( - l , l )$ 上的,偶函数 $g ( x )$ 及奇函数 $h ( x )$ , 使得 $f ( x ) = g ( x ) + h ( x )$

# 5. 初等函数

定义 将幂函数 ,指数,对数,三角,反三角统称为基本初等函数.了解它们的定义域,性质,图形.

幂函数 y= xu

指数函数 xy  a

对数函数

三角函数

反三角函数 x,

定义 由常数和基本初等函数经过有限次的加、减、乘、

除和复合所得到且能用一个解析式表示的函数,称为初等函数.

# 内容小结

定义域1.函数的定义及函数的二要素对应法则  
2.函数的特性 有界性, 单调性,奇偶性, 周期性  
3.复合函数与反函数  
4.基本初等函数与初等函数

# 作业

P16 6; 7 (4),(5),(6); 8;

9 (1),(2),(5); 12 ; 13;